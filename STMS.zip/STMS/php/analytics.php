<?php
include 'db.php'; // Include database connection

// Fetch booking count by status
$bookingStats = $conn->query("SELECT status, COUNT(*) AS count FROM bookings GROUP BY status");

// Fetch total revenue
$revenueQuery = $conn->query("SELECT COALESCE(SUM(amount), 0) AS total_revenue FROM payments WHERE status = 'completed'");
$revenue = $revenueQuery->fetch_assoc();

// Fetch payment details
$paymentDetails = $conn->query("SELECT id, amount, status, created_at FROM payments");

// Fetch user details (fixing the query to avoid unknown column 'user_id')
$userDetails = $conn->query("SELECT id, name, email, role FROM users");

// Fetch tour details
$tourDetails = $conn->query("SELECT id, title, description, price FROM tours");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

        :root {
            --primary-color: #ff833e;
            --primary-color-dark: #db6f35;
            --text-dark: #333333;
            --text-light: #767268;
            --white: #ffffff;
            --max-width: 1200px;
            --header-font: "Bebas Neue", sans-serif;
        }

        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        a {
            text-decoration: none;
            transition: 0.3s;
        }
        nav {
  position: fixed;
  isolation: isolate;
  width: 100%;
  z-index: 9;
}

.nav__header {
  padding: 1rem;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: var(--primary-color);
}

.nav__logo a {
  font-size: 1.75rem;
  font-weight: 400;
  font-family: var(--header-font);
  color: var(--white);
}

.nav__menu__btn {
  font-size: 1.5rem;
  color: var(--white);
  cursor: pointer;
}

.nav__links {
  position: absolute;
  top: 64px;
  left: 0;
  width: 100%;
  padding: 2rem;
  list-style: none;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  gap: 2rem;
  background-color: var(--primary-color);
  transition: 0.5s;
  z-index: -1;
  transform: translateY(-100%);
}

.nav__links.open {
  transform: translateY(0);
}

.nav__links a {
  font-weight: 500;
  color: var(--white);
}

.nav__links a:hover {
  color: var(--text-dark);
}

.nav__btns {
  display: none;
}

@media (width > 768px) {
  nav {
    position: static;
    padding-block: 2rem 0;
    padding-inline: 1rem;
    max-width: var(--max-width);
    margin-inline: auto;
    display: flex;
    align-items: center;
    justify-content: space-around;
    gap: 2rem;
  }
  .nav__header {
    flex: 1;
    padding: 0;
    background-color:transparent;
  }
  .nav__logo a {
    color: var(--text-dark);
  }
  .nav__logo a span {
    color: var(--primary-color);
  }
  .nav__menu__btn {
    display: none;
  }
  .nav__links {
    position: static;
    padding: 0;
    flex-direction: row;
    background-color: transparent;
    transform: none;
  }
  .nav__links a {
    padding-block: 5px;
    color: var(--text-dark);
    border-bottom: 4px solid transparent;
  }
  .nav__links a:hover {
    border-color: var(--primary-color);
  }
  .nav__btns {
    display: flex;
    flex: 1;
  }
  .nav__btns .btn {
    padding: 0.75rem 1.5rem;
    outline: none;
    border: none;
    font-size: 1rem;
    white-space: nowrap;
    border-radius: 10px;
    transition: 0.3s;
    cursor: pointer;
  }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px;
            text-align: left;
            font-size: 1rem;
            color: #555;
        }

        th {
            background-color: #ff833e;
            color: white;
        }

        td {
            background-color: #f9f9f9;
            border-bottom: 1px solid #ddd;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .total-revenue {
            font-size: 1.25rem;
            color: #333;
            text-align: right;
            margin-top: 30px;
            font-weight: bold;
        }

        .button {
            display: inline-block;
            background-color: #ff833e;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            margin-top: 20px;
            text-align: center;
        }

        .button:hover {
            background-color: #db6f35;
        }

        .logout-btn {
            background-color: #ff833e;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .logout-btn:hover {
            background-color: #e67e22;
        }
    </style>
</head>
<body>

<header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="../index.php">Home</a></li>
                <li><a href="tour_management.php">Tour Management</a></li>
                <li><a href="booking.php">Bookings</a></li>
                <li><a href="user_management.php">User Management</a></li>
                <li><a href="payment_management.php">Payment Management</a></li>
                <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li>
                <form action="logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>

<div class="container">
    <h1>Booking Analytics</h1>

    <!-- Booking Stats Table -->
    <h2>Booking Stats</h2>
    <table>
        <thead>
            <tr>
                <th>Status</th>
                <th>Booking Count</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $bookingStats->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><?php echo (int)$row['count']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Total Revenue -->
    <div class="total-revenue">
        Total Revenue: $<?php echo number_format((float)$revenue['total_revenue'], 2); ?>
    </div>

    <!-- Tour Details -->
    <h2>Tour Details</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $tourDetails->fetch_assoc()): ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['description']); ?></td>
                    <td>$<?php echo number_format((float)$row['price'], 2); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Payment Details -->
    <h2>Payment Details</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $paymentDetails->fetch_assoc()): ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td>$<?php echo number_format((float)$row['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- User Details -->
    <h2>User Details</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $userDetails->fetch_assoc()): ?>
                <tr>
                    <td><?php echo (int)$row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['role']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</div>

</body>
</html>
