<?php
// Include database connection
include 'db.php';

// Start the session (if needed)
session_start();

// Check if the user is logged in (optional)
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Handle Update Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id']) && !isset($_POST['action'])) {
    // Validate and sanitize inputs
    $booking_id = intval($_POST['booking_id']);
    $user_id = intval($_POST['user_id']);
    $tour_id = intval($_POST['tour_id']);
    $status = $_POST['status'];

    // Validate status
    $allowed_statuses = ['pending', 'confirmed', 'cancelled'];
    if (!in_array($status, $allowed_statuses)) {
        $_SESSION['error'] = "Invalid status value";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Prepare and execute the update query
    $query = "UPDATE bookings SET user_id = ?, tour_id = ?, status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iisi", $user_id, $tour_id, $status, $booking_id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Booking updated successfully";
    } else {
        $_SESSION['error'] = "Error updating booking: " . $conn->error;
    }

    $stmt->close();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Handle DELETE request via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $booking_id = intval($_POST['booking_id']);
    $delete_query = "DELETE FROM bookings WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $booking_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch all bookings
    $query = "
        SELECT b.id, u.name AS user, t.title AS tour, b.status, b.created_at,
               b.user_id, b.tour_id
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN tours t ON b.tour_id = t.id
    ";

    $result = $conn->query($query);

    if (!$result) {
        echo '<p>Error fetching bookings: ' . htmlspecialchars($conn->error) . '</p>';
        exit;
    }

    // Fetch users and tours for the update form
    $users_query = "SELECT id, name FROM users";
    $users_result = $conn->query($users_query);
    $tours_query = "SELECT id, title FROM tours";
    $tours_result = $conn->query($tours_query);

    // Start HTML output
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Management</title>
        <link rel="stylesheet" href="../css/styles.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <style>
            .modal {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }
            .modal-content {
                background-color: white;
                margin: 15% auto;
                padding: 20px;
                width: 70%;
                max-width: 500px;
                border-radius: 5px;
            }
            .close {
                float: right;
                cursor: pointer;
                font-size: 28px;
            }
            .action-buttons {
                display: flex;
                gap: 10px;
            }
            .action-buttons button {
                padding: 5px 10px;
                cursor: pointer;
            }
            .edit-btn {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 3px;
            }
            .delete-btn {
                background-color: #f44336;
                color: white;
                border: none;
                border-radius: 3px;
            }
            .alert {
                padding: 10px;
                margin: 10px 0;
                border-radius: 4px;
            }
            .alert-success {
                background-color: #dff0d8;
                border-color: #d6e9c6;
                color: #3c763d;
            }
            .alert-error {
                background-color: #f2dede;
                border-color: #ebccd1;
                color: #a94442;
            }
        </style>
    </head>
    <body>
    <header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="../index.php">Home</a></li>
                <li><a href="tour_management.php">Tour Management</a></li>
                <li><a href="booking.php">Bookings</a></li>
                <li><a href="user_management.php">User Management</a></li>
                <li><a href="payment_management.php">Payment Management</a></li>
                <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li>
                <form action="logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>
        <div class="container">
            <div class="main-content">
                <div class="navbar">
                    <h1>Bookings</h1>
                </div>

                <?php
                // Display success/error messages if any
                if (isset($_SESSION['success'])) {
                    echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
                    unset($_SESSION['success']);
                }
                if (isset($_SESSION['error'])) {
                    echo '<div class="alert alert-error">' . htmlspecialchars($_SESSION['error']) . '</div>';
                    unset($_SESSION['error']);
                }
                ?>

                <table border="1">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Tour</th>
                        <th>Status</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                    <?php
                    // Fetch and display each booking
                    while ($row = $result->fetch_assoc()) {
                        echo '<tr>
                                <td>' . htmlspecialchars($row['id']) . '</td>
                                <td>' . htmlspecialchars($row['user']) . '</td>
                                <td>' . htmlspecialchars($row['tour']) . '</td>
                                <td>' . htmlspecialchars($row['status']) . '</td>
                                <td>' . htmlspecialchars($row['created_at']) . '</td>
                                <td class="action-buttons">
                                    <button class="edit-btn" onclick="openEditModal(' . 
                                        htmlspecialchars($row['id']) . ', ' .
                                        htmlspecialchars($row['user_id']) . ', ' .
                                        htmlspecialchars($row['tour_id']) . ', \'' .
                                        htmlspecialchars($row['status']) . '\')">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="delete-btn" onclick="deleteBooking(' . htmlspecialchars($row['id']) . ')">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </td>
                              </tr>';
                    }
                    ?>
                </table>
            </div>
        </div>

        <!-- Edit Modal -->
        <div id="editModal" class="modal">
            <div class="modal-content">
                <span class="close" onclick="closeEditModal()">&times;</span>
                <h2>Edit Booking</h2>
                <form id="editForm" method="POST">
                    <input type="hidden" id="booking_id" name="booking_id">
                    <div>
                        <label for="user_id">User:</label>
                        <select name="user_id" id="user_id" required>
                            <?php
                            while ($user = $users_result->fetch_assoc()) {
                                echo '<option value="' . htmlspecialchars($user['id']) . '">' . 
                                     htmlspecialchars($user['name']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="tour_id">Tour:</label>
                        <select name="tour_id" id="tour_id" required>
                            <?php
                            while ($tour = $tours_result->fetch_assoc()) {
                                echo '<option value="' . htmlspecialchars($tour['id']) . '">' . 
                                     htmlspecialchars($tour['title']) . '</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div>
                        <label for="status">Status:</label>
                        <select name="status" id="status" required>
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>
                    <button type="submit">Update Booking</button>
                </form>
            </div>
        </div>

        <script>
            function openEditModal(id, userId, tourId, status) {
                document.getElementById("editModal").style.display = "block";
                document.getElementById("booking_id").value = id;
                document.getElementById("user_id").value = userId;
                document.getElementById("tour_id").value = tourId;
                document.getElementById("status").value = status;
            }

            function closeEditModal() {
                document.getElementById("editModal").style.display = "none";
            }

            function deleteBooking(id) {
                if (confirm("Are you sure you want to delete this booking?")) {
                    fetch("", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded",
                        },
                        body: "action=delete&booking_id=" + id
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            alert("Error deleting booking: " + data.error);
                        }
                    })
                    .catch(error => {
                        console.error("Error:", error);
                        alert("Error deleting booking");
                    });
                }
            }

            // Close modal when clicking outside of it
            window.onclick = function(event) {
                if (event.target == document.getElementById("editModal")) {
                    closeEditModal();
                }
            }
        </script>
    </body>
    </html>
    <?php
}
?>