<?php
include 'db.php';

// Fetch all payments from the database
$payments = [];
$query = "
    SELECT p.id, b.id AS booking_id, p.amount, p.payment_method, p.status, p.created_at 
    FROM payments p 
    JOIN bookings b ON p.booking_id = b.id
";
$result = $conn->query($query);

if (!$result) {
    die('Error executing query: ' . $conn->error);  // Error handling if query fails
}

while ($row = $result->fetch_assoc()) {
    $payments[] = $row;
}

// Handle status update and payment deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id']) && isset($_POST['status'])) {
        // Update payment status
        $paymentId = $_POST['id'];
        $status = $_POST['status'];

        $query = "UPDATE payments SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('si', $status, $paymentId);

        if ($stmt->execute()) {
            echo json_encode(['success' => 'Payment status updated successfully.']);
        } else {
            echo json_encode(['error' => 'Failed to update payment status.']);
        }
        $stmt->close();
    } elseif (isset($_POST['delete_id'])) {
        // Delete payment
        $paymentId = $_POST['delete_id'];

        $query = "DELETE FROM payments WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $paymentId);

        if ($stmt->execute()) {
            echo json_encode(['success' => 'Payment deleted successfully.']);
        } else {
            echo json_encode(['error' => 'Failed to delete payment.']);
        }
        $stmt->close();
    }
    exit();  // Ensure no other content is sent after JSON response
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Management</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<header>
    <nav>
        <div class="nav__header">
            <div class="nav__logo">
                <a href="index.php">SMART<span>TOUR</span>.</a>
            </div>
            <div class="nav__menu__btn" id="menu-btn">
                <span><i class="ri-menu-line"></i></span>
            </div>
        </div>
        <ul class="nav__links" id="nav-links">
            <li><a href="../index.php">Home</a></li>
            <li><a href="tour_management.php">Tour Management</a></li>
            <li><a href="booking.php">Bookings</a></li>
            <li><a href="user_management.php">User Management</a></li>
            <li><a href="payment_management.php">Payment Management</a></li>
            <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
            <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
            <li>
                <form action="logout.php" method="POST" style="display: inline;">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </li>
        </ul>
    </nav>
</header>

<div class="container">
    <div class="main-content">
        <div class="navbar">
            <h1>Payments</h1>
        </div>
        <h1>Payment Management</h1>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Booking ID</th>
                    <th>Amount</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="paymentsTableBody">
                <?php foreach ($payments as $payment): ?>
                    <tr>
                        <td><?= htmlspecialchars($payment['id']) ?></td>
                        <td><?= htmlspecialchars($payment['booking_id']) ?></td>
                        <td><?= htmlspecialchars($payment['amount']) ?></td>
                        <td><?= htmlspecialchars($payment['payment_method']) ?></td>
                        <td>
                            <!-- Display the status as a text label -->
                            <span class="statusLabel"><?= htmlspecialchars(ucfirst($payment['status'])) ?></span>
                        </td>
                        <td><?= htmlspecialchars($payment['created_at']) ?></td>
                        <td>
                            <button class="updateStatus" data-id="<?= htmlspecialchars($payment['id']) ?>">Update</button>
                            <button class="deletePayment" data-id="<?= htmlspecialchars($payment['id']) ?>">Delete</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        // Attach event listeners to update buttons
        document.querySelectorAll(".updateStatus").forEach((button) => {
            button.addEventListener("click", function () {
                const paymentId = this.dataset.id;
                const newStatus = prompt("Enter the new status (paid, pending, refunded):");

                if (newStatus && ["paid", "pending", "refunded"].includes(newStatus.toLowerCase())) {
                    // Update payment status via POST request
                    fetch("payment_management.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: `id=${paymentId}&status=${newStatus}`,
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            alert(data.success || data.error);
                            if (data.success) {
                                location.reload(); // Reload page to reflect status update
                            }
                        })
                        .catch((error) => {
                            alert("Failed to update status: " + error.message);
                        });
                } else {
                    alert("Invalid status entered. Please enter 'paid', 'pending', or 'refunded'.");
                }
            });
        });

        // Attach event listener to delete buttons
        document.querySelectorAll(".deletePayment").forEach((button) => {
            button.addEventListener("click", function () {
                const paymentId = this.dataset.id;

                if (confirm('Are you sure you want to delete this payment?')) {
                    // Delete payment via POST request
                    fetch("payment_management.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: `delete_id=${paymentId}`,
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            alert(data.success || data.error);
                            if (data.success) {
                                // Reload page to reflect changes
                                location.reload();
                            }
                        })
                        .catch((error) => {
                            alert("Failed to delete payment: " + error.message);
                        });
                }
            });
        });
    });
</script>

</body>
</html>
