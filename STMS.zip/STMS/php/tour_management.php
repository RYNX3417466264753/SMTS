<?php
include 'db.php'; // Include the database connection

// Create Tour
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_tour'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $available_slots = $_POST['available_slots'];
    $destination = $_POST['destination'];

    $stmt = $conn->prepare("INSERT INTO tours (title, description, price, available_slots, destination) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdis", $title, $description, $price, $available_slots, $destination);
    $stmt->execute();
}

// Read Tours
$result = $conn->query("SELECT * FROM tours");
$tours = $result->fetch_all(MYSQLI_ASSOC);

// Update Tour
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_tour'])) {
    $tourId = $_POST['tour_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $available_slots = $_POST['available_slots'];
    $destination = $_POST['destination'];

    $stmt = $conn->prepare("UPDATE tours SET title = ?, description = ?, price = ?, available_slots = ?, destination = ? WHERE id = ?");
    $stmt->bind_param("ssdisi", $title, $description, $price, $available_slots, $destination, $tourId);
    $stmt->execute();
}

// Delete Tour
if (isset($_GET['delete_tour'])) {
    $tourId = $_GET['delete_tour'];
    $stmt = $conn->prepare("DELETE FROM tours WHERE id = ?");
    $stmt->bind_param("i", $tourId);
    $stmt->execute();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tour Management</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="../index.php">Home</a></li>
                <li><a href="tour_management.php">Tour Management</a></li>
                <li><a href="booking.php">Bookings</a></li>
                <li><a href="user_management.php">User Management</a></li>
                <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="payment_management.php">Payment Management</a></li>
                <li>
                <form action="logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>
    <h1>Tour Management</h1>
    <form method="POST">
        <h2>Create Tour</h2>
        <input type="text" name="title" placeholder="Tour Title" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="number" name="price" placeholder="Price" required>
        <input type="number" name="available_slots" placeholder="Available Slots" required>
        <input type="text" name="destination" placeholder="Destination" required>
        <button type="submit" name="create_tour">Create Tour</button>
    </form>

    <h2>Tours List</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            <th>Available Slots</th>
            <th>Destination</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($tours as $tour): ?>
        <tr>
            <td><?php echo $tour['id']; ?></td>
            <td id="title-<?php echo $tour['id']; ?>"><?php echo $tour['title']; ?></td>
            <td id="description-<?php echo $tour['id']; ?>"><?php echo $tour['description']; ?></td>
            <td id="price-<?php echo $tour['id']; ?>"><?php echo $tour['price']; ?></td>
            <td id="slots-<?php echo $tour['id']; ?>"><?php echo $tour['available_slots']; ?></td>
            <td id="destination-<?php echo $tour['id']; ?>"><?php echo $tour['destination']; ?></td>
            <td>
                <form method="POST" style="display: none;" id="edit-form-<?php echo $tour['id']; ?>">
                    <input type="hidden" name="tour_id" value="<?php echo $tour['id']; ?>">
                    <input type="text" name="title" value="<?php echo $tour['title']; ?>" required>
                    <textarea name="description" required><?php echo $tour['description']; ?></textarea>
                    <input type="number" name="price" value="<?php echo $tour['price']; ?>" required>
                    <input type="number" name="available_slots" value="<?php echo $tour['available_slots']; ?>" required>
                    <input type="text" name="destination" value="<?php echo $tour['destination']; ?>" required>
                    <button type="submit" name="update_tour">Save</button>
                    <button type="button" onclick="cancelEdit('<?php echo $tour['id']; ?>')">Cancel</button>
                </form>
                <button onclick="startEdit('<?php echo $tour['id']; ?>')" id="edit-button-<?php echo $tour['id']; ?>">Update</button>
                <a href="?delete_tour=<?php echo $tour['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script>
        function startEdit(tourId) {
            document.getElementById(`edit-form-${tourId}`).style.display = "block";
            document.getElementById(`edit-button-${tourId}`).style.display = "none";
        }

        function cancelEdit(tourId) {
            document.getElementById(`edit-form-${tourId}`).style.display = "none";
            document.getElementById(`edit-button-${tourId}`).style.display = "inline";
        }
    </script>
</body>
</html>
