<?php
include 'db.php';

header('Content-Type: application/json'); // Set JSON response type for all responses

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch all payments
    $query = "
        SELECT p.id, b.id AS booking_id, p.amount, p.status, p.created_at
        FROM payments p
        JOIN bookings b ON p.booking_id = b.id
    ";
    $result = $conn->query($query);

    if (!$result) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to fetch payments']);
        exit;
    }

    $payments = [];
    while ($row = $result->fetch_assoc()) {
        $payments[] = $row;
    }

    echo json_encode($payments);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate input
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);

    // Validate status against allowed values
    $allowedStatuses = ['paid', 'pending', 'refunded'];
    if (!$id || !in_array($status, $allowedStatuses)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid input']);
        exit;
    }

    // Use prepared statement to update payment status
    $stmt = $conn->prepare("UPDATE payments SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $status, $id);

    if ($stmt->execute()) {
        echo json_encode(['success' => "Payment status updated to $status"]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update payment status']);
    }

    $stmt->close();
    exit;
}

// Handle unsupported methods
http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
?>
