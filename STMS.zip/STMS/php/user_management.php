<?php
include 'db.php'; // Include the database connection

// Read Users
try {
    $stmt = $conn->prepare("SELECT id, username, email, name FROM users");
    $stmt->execute();
    $result = $stmt->get_result();
    $users = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    $users = [];
    echo "Error loading users: " . $e->getMessage();
}

// Create User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $email = $_POST['email'] ?? '';
    $name = $_POST['name'] ?? '';

    if (!empty($username) && !empty($password) && !empty($email) && !empty($name)) {
        $password = password_hash($password, PASSWORD_DEFAULT);
        try {
            $stmt = $conn->prepare("INSERT INTO users (username, password, email, name) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $password, $email, $name);
            $stmt->execute();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } catch (Exception $e) {
            echo "Error creating user: " . $e->getMessage();
        }
    }
}

// Update User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $userId = $_POST['user_id'] ?? '';
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $name = $_POST['name'] ?? '';

    if (!empty($userId) && !empty($username) && !empty($email) && !empty($name)) {
        try {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, name = ? WHERE id = ?");
            $stmt->bind_param("sssi", $username, $email, $name, $userId);
            $stmt->execute();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } catch (Exception $e) {
            echo "Error updating user: " . $e->getMessage();
        }
    }
}

// Delete User
if (isset($_GET['delete_user'])) {
    $userId = $_GET['delete_user'] ?? '';
    if (!empty($userId)) {
        try {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } catch (Exception $e) {
            echo "Error deleting user: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="../index.php">Home</a></li>
                <li><a href="tour_management.php">Tour Management</a></li>
                <li><a href="booking.php">Bookings</a></li>
                <li><a href="php/user_management.php">User Management</a></li>
                <li><a href="payment_management.php">Payment Management</a></li>
                <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li>
                <form action="logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>
<div class="container">
            
            <div class="main-content">
                <div class="navbar">
                    <h1>Bookings</h1>
                </div>
    <div class="container">
        <h1>User Management</h1>
        
        <!-- Create User Form -->
        <div class="create-user-form">
            <form method="POST" onsubmit="return validateForm()">
                <h2>Create User</h2>
                <div class="form-group">
                    <input type="text" name="username" placeholder="Username" required minlength="3" maxlength="50">
                </div>
                <div class="form-group">
                    <input type="password" name="password" placeholder="Password" required minlength="8">
                </div>
                <div class="form-group">
                    <input type="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="text" name="name" placeholder="Full Name" required>
                </div>
                <button type="submit" name="create_user" class="btn-create">Create User</button>
            </form>
        </div>

        <!-- Users List -->
        <div class="users-list">
            <h2>Users List</h2>
            <?php if (!empty($users)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['username'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($user['name'] ?? ''); ?></td>
                        <td class="actions">
                            <!-- Edit Form -->
                            <form method="POST" style="display:none;" id="edit-form-<?php echo htmlspecialchars($user['id'] ?? ''); ?>" class="edit-form">
                                <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id'] ?? ''); ?>">
                                <input type="text" name="username" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" required minlength="3" maxlength="50">
                                <input type="email" name="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                                <input type="text" name="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
                                <button type="submit" name="update_user" class="btn-save">Save</button>
                                <button type="button" onclick="cancelEdit('<?php echo htmlspecialchars($user['id'] ?? ''); ?>')" class="btn-cancel">Cancel</button>
                            </form>

                            <!-- Action Buttons -->
                            <button onclick="startEdit('<?php echo htmlspecialchars($user['id'] ?? ''); ?>')" id="edit-button-<?php echo htmlspecialchars($user['id'] ?? ''); ?>" class="btn-edit">
                                <i class="fas fa-edit"></i> Update
                            </button>
                            <a href="?delete_user=<?php echo htmlspecialchars($user['id'] ?? ''); ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this user?')">
                                <i class="fas fa-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
                <p>No users found.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function validateForm() {
            const password = document.querySelector('input[name="password"]');
            if (password && password.value.length < 8) {
                alert('Password must be at least 8 characters long');
                return false;
            }
            return true;
        }

        function startEdit(userId) {
            document.getElementById(`edit-form-${userId}`).style.display = "block";
            document.getElementById(`edit-button-${userId}`).style.display = "none";
        }

        function cancelEdit(userId) {
            document.getElementById(`edit-form-${userId}`).style.display = "none";
            document.getElementById(`edit-button-${userId}`).style.display = "inline-block";
        }

        document.addEventListener('DOMContentLoaded', function() {
            const forms = document.querySelectorAll('form');
            forms.forEach(form => {
                form.addEventListener('submit', function(e) {
                    const requiredFields = form.querySelectorAll('[required]');
                    let valid = true;
                    
                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            valid = false;
                            field.classList.add('error');
                        } else {
                            field.classList.remove('error');
                        }
                    });

                    if (!valid) {
                        e.preventDefault();
                        alert('Please fill in all required fields');
                    }
                });
            });
        });
    </script>
</body>
</html>