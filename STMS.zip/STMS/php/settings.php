<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch current settings
    $settings = $conn->query("SELECT * FROM settings LIMIT 1")->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update system settings
    $site_name = $_POST['site_name'];
    $admin_email = $_POST['admin_email'];
    $conn->query("UPDATE settings SET site_name = '$site_name', admin_email = '$admin_email' WHERE id = 1");
    echo "Settings updated";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Settings</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="../js/script.js"></script> <!-- Include the script.js file -->
</head>
<body>
<header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="../index.php">Home</a></li>
                <li><a href="tour_management.php">Tour Management</a></li>
                <li><a href="booking.php">Bookings</a></li>
                <li><a href="user_management.php">User Management</a></li>
                <li><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="payment_management.php">Payment Management</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li>
                <form action="logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>
<div class="container">
            <div class="main-content">
                <div class="navbar">
                    <h1>Bookings</h1>
                </div>
    <h1>System Settings</h1>
    <form id="settingsForm" method="POST">
        <div>
            <label for="site_name">Site Name:</label>
            <input type="text" name="site_name" value="<?php echo htmlspecialchars($settings['site_name']); ?>" required>
        </div>
        <div>
            <label for="admin_email">Admin Email:</label>
            <input type="email" name="admin_email" value="<?php echo htmlspecialchars($settings['admin_email']); ?>" required>
        </div>
        <button type="submit">Update Settings</button>
    </form>
    <script src="./js/script.js"></script>
</body>
</html>