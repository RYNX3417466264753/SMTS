function validateForm() {
  const Firstname = document.getElementById("Firstname").value;
  const Lastname = document.getElementById("Lastname").value;
  const Email = document.getElementById("Email").value;
  const Password = document.getElementById("Password").value;
  const ConfirmPassword = document.getElementById("confirmpassword").value;

  // Validation checks
  if (Firstname === "") {
      showError("First name is required.");
      return false;
  } else if (!isAlphabetOnly(Firstname)) {
      showError("First name should contain only letters.");
      return false;
  }

  if (Lastname === "") {
      showError("Last name is required.");
      return false;
  } else if (!isAlphabetOnly(Lastname)) {
      showError("Last name should contain only letters.");
      return false;
  }

  if (Email === "") {
      showError("Email is required.");
      return false;
  } else if (!validateEmail(Email)) {
      showError("Please enter a valid email address.");
      return false;
  }

  if (Password === "") {
      showError("Password is required.");
      return false;
  } else if (!validatePassword(Password)) {
      showError("Password must be at least 8 characters long, include uppercase and lowercase letters, a number, and a special character.");
      return false;
  }

  if (Password !== ConfirmPassword) {
      showError("Passwords do not match.");
      return false;
  }

  window.location.href = "../login.html";
  return true;
}

// Helper function to check if input contains only alphabet letters
function isAlphabetOnly(input) {
  const regex = /^[A-Za-z]+$/;
  return regex.test(input);
}

// Helper function to validate email format
function validateEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// Helper function to validate password criteria
function validatePassword(password) {
  // Minimum 8 characters, at least one uppercase, one lowercase, one number, and one special character
  const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return regex.test(password);
}

// Function to show error message
function showError(message) {
  alert(message); // This could be improved by displaying the error message in the form instead of an alert
}

function togglePasswordVisibility(fieldId) {
  const passwordField = document.getElementById(fieldId);
  const type = passwordField.type === "password" ? "text" : "password";
  passwordField.type = type;
}