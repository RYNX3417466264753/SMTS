<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'stms');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);

    // Verify token
    $query = "SELECT * FROM users WHERE reset_token='$token' AND token_expires > NOW()";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Update password and clear token
        $update = "UPDATE users SET password='$new_password', reset_token=NULL, token_expires=NULL WHERE reset_token='$token'";
        if ($conn->query($update)) {
            echo "Password successfully reset. <a href='login.html'>Login here</a>";
        } else {
            echo "Error updating password.";
        }
    } else {
        echo "Invalid or expired token.";
    }
}
$conn->close();
?>