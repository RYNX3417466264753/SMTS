<?php
// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Load Composer's autoloader

// Database connection
$conn = new mysqli('localhost', 'root', '', 'stms');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // Check if email exists
    $query = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Generate a password reset token
        $token = bin2hex(random_bytes(50));
        $expires = date("Y-m-d H:i:s", strtotime("+1 hour")); // 1-hour expiration

        // Store the token in the database
        $update = "UPDATE users SET reset_token='$token', token_expires='$expires' WHERE email='$email'";
        if ($conn->query($update)) {
            // Send password reset email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; // Your SMTP server (Gmail example)
                $mail->SMTPAuth   = true;
                $mail->Username   = 'your_email@gmail.com'; // Your email
                $mail->Password   = 'your_email_password'; // Your email password or app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Recipients
                $mail->setFrom('your_email@gmail.com', 'Tourism System');
                $mail->addAddress($email); // User's email

                // Content
                $resetLink = "http://yourwebsite.com/reset_password.html?token=$token";
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body    = "Click this link to reset your password: <a href='$resetLink'>$resetLink</a>";

                $mail->send();
                echo "A reset link has been sent to your email.";
            } catch (Exception $e) {
                echo "Failed to send email. Error: {$mail->ErrorInfo}";
            }
        }
    } else {
        echo "No account found with that email.";
    }
}
$conn->close();
?>
