<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: php/login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Tour Admin Dashboard</title>
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="index.php" target="_self">Home</a></li>
                <li><a href="php/tour_management.php">Tour Management</a></li>
                <li><a href="php/booking.php">Bookings</a></li>
                <li><a href="php/user_management.php">User Management</a></li>
                <li><a href="php/payment_management.php">Payment Management</a></li>
                <li><a href="php/analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="php/settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li>
                <form action="php/logout.php" method="POST" style="display: inline;">
                            <button type="submit" class="logout-btn">Logout</button>
                        </form>
                </li>
            </ul>
        </nav>
    </header>
        <div class="main-content">
            <div class="navbar">
                <h1> ADMIN DASHBOARD</h1>          
            </div>
            <div class="overview">
                <div class="overview-card">
                    <h3>Users</h3>
                    <p>Manage all registered users in the system</p>
                </div>
                <div class="overview-card">
                    <h3>Tours</h3>
                    <p>Track and organize available tours</p>
                </div>
                <div class="overview-card">
                    <h3>Bookings</h3>
                    <p>Monitor and manage bookings effectively</p>
                </div>
                <div class="overview-card">
                    <h3>Analytics</h3>
                    <p>Gain insights with detailed analytics</p>
                </div>
            </div>
            <section class="about" id="about">
        <h2>About Us</h2>
        
        <div id="about-tour" class="tab-content active">
            <p>SmartTour is a leading tour management company dedicated to providing unforgettable travel experiences in the beautiful Northern Malawi region. With decades of industry expertise, we have curated a diverse portfolio of unique tours that showcase the true essence of Malawian culture, natural wonders, and adventurous activities. Our team of passionate local guides and travel experts work tirelessly to ensure every trip exceeds our guests' expectations.</p>
        </div>
        
        <div id="mission" class="tab-content">
            <h3>Our Mission</h3>
            <p>At the heart of SmartTour lies our unwavering commitment to responsible and sustainable tourism. Our mission is to connect travelers with the breathtaking beauty and rich cultural heritage of Malawi, while prioritizing the well-being of local communities and the preservation of the environment. We believe in empowering our guests to explore the country in a way that creates positive social and economic impact, fostering meaningful connections and lasting memories.</p>
        </div>

        <div id="safety" class="tab-content">
            <h3>Safety Information</h3>
            <p>Ensuring the safety and security of our guests is of the utmost importance at SmartTour. We adhere to the highest industry standards and protocols to mitigate risks and provide a worry-free travel experience. From comprehensive safety briefings and emergency response procedures to the use of well-maintained transportation and equipment, we leave no stone unturned in our pursuit of keeping our travelers safe.</p>
        </div>
    </section>
<!--footer-->
    <footer>
    <div class="footer-container">
        <div class="footer-description">
            <h3>About SmartTour</h3>
            <p>Explore the stunning landscapes and vibrant culture of Northern Malawi with us. Join us for unforgettable experiences!</p>
        </div>
        
        <div class="footer-social">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href=""><i class="ri-facebook-fill"></i></a>
                <a href="#"><i class="ri-twitter-fill"></i></a>
                <a href="#"><i class="ri-instagram-fill"></i></a>
                <a href="#"><i class="ri-linkedin-fill"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2024 Smart Tour. All rights reserved.</p>
    </div>
</footer>
        </div>
</body>
</html>