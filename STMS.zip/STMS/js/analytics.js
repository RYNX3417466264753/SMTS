
// JavaScript for Analytics

fetch('php/analytics.php')
    .then(response => response.json())
    .then(data => {
        const bookingStats = data.bookingStats;
        const revenue = data.revenue;

        // Display stats in console (can be rendered on canvas)
        console.log('Booking Stats:', bookingStats);
        console.log('Total Revenue:', revenue);
    });
