// JavaScript for interactive features

// Function to validate the login form
function validateLoginForm() {
    const username = document.querySelector('input[name="username"]');
    const password = document.querySelector('input[name="password"]');

    if (username.value.trim() === "") {
        alert("Username is required.");
        username.focus();
        return false;
    }

    if (password.value.trim() === "") {
        alert("Password is required.");
        password.focus();
        return false;
    }

    return true;
}

// Function to validate the tour management form
function validateTourForm() {
    const title = document.querySelector('input[name="title"]');
    const description = document.querySelector('textarea[name="description"]');
    const price = document.querySelector('input[name="price"]');
    const availableSlots = document.querySelector('input[name="available_slots"]');
    const destination = document.querySelector('input[name="destination"]');

    if (title.value.trim() === "") {
        alert("Tour title is required.");
        title.focus();
        return false;
    }

    if (description.value.trim() === "") {
        alert("Description is required.");
        description.focus();
        return false;
    }

    if (price.value === "" || isNaN(price.value) || parseFloat(price.value) <= 0) {
        alert("Valid price is required.");
        price.focus();
        return false;
    }

    if (availableSlots.value === "" || isNaN(availableSlots.value) || parseInt(availableSlots.value) <= 0) {
        alert("Valid available slots are required.");
        availableSlots.focus();
        return false;
    }

    if (destination.value.trim() === "") {
        alert("Destination is required.");
        destination.focus();
        return false;
    }

    return true;
}

// Function to validate the user management form
function validateUserForm() {
    const username = document.querySelector('input[name="username"]');
    const email = document.querySelector('input[name="email"]');
    const name = document.querySelector('input[name="name"]');

    if (username.value.trim() === "") {
        alert("Username is required.");
        username.focus();
        return false;
    }

    if (email.value.trim() === "" || !validateEmail(email.value)) {
        alert("Valid email is required.");
        email.focus();
        return false;
    }

    if (name.value.trim() === "") {
        alert("Full name is required.");
        name.focus();
        return false;
    }

    return true;
}

// Email validation helper function
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}

// Function to validate settings form
function validateSettingsForm() {
    const siteName = document.querySelector('input[name="site_name"]');
    const adminEmail = document.querySelector('input[name="admin_email"]');

    if (siteName.value.trim() === "") {
        alert("Site name is required.");
        siteName.focus();
        return false;
    }

    if (adminEmail.value.trim() === "" || !validateEmail(adminEmail.value)) {
        alert("Valid admin email is required.");
        adminEmail.focus();
        return false;
    }

    return true;
}

// Function to validate payment form (if applicable)
function validatePaymentForm() {
    const paymentStatus = document.querySelector('select[name="payment_status"]');

    if (!paymentStatus.value) {
        alert("Payment status is required.");
        paymentStatus.focus();
        return false;
    }

    return true;
}

// Attach event listeners to forms
document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.querySelector("#loginForm");
    const tourForm = document.querySelector("#tourForm");
    const userForm = document.querySelector("#userForm");
    const settingsForm = document.querySelector("#settingsForm");
    const paymentForm = document.querySelector("#paymentForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function(event) {
            if (!validateLoginForm()) {
                event.preventDefault();
            }
        });
    }

    if (tourForm) {
        tourForm.addEventListener("submit", function(event) {
            if (!validateTourForm()) {
                event.preventDefault();
            }
        });
    }

    if (userForm) {
        userForm.addEventListener("submit", function(event) {
            if (!validateUserForm()) {
                event.preventDefault();
            }
        });
    }

    if (settingsForm) {
        settingsForm.addEventListener("submit", function(event) {
            if (!validateSettingsForm()) {
                event.preventDefault();
            }
        });
    }

    if (paymentForm) {
        paymentForm.addEventListener("submit", function(event) {
            if (!validatePaymentForm()) {
                event.preventDefault();
            }
        });
    }
});
