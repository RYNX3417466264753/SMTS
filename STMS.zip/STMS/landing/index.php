<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet" />
    <link rel="stylesheet" href="Style.css" />
    <title>SmartTour | Discover Northern Malawi</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="index.php">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="/packages/packages.php">Tour Packages</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="ContactUs.php" target="_self">Contact</a></li>
            </ul>
            <div class="nav__btns">
                <a href=""><button class="btn sign__up">Sign Up</button></a>
                <a href=""><button class="btn sign__in">Sign In</button></a>
            </div>
        </nav>
    </header>
    
    <!-- Hero Section -->
    <section class="hero">
        <h1>Discover the Beauty of <span>Northern Malawi</span></h1>
        <p>Book your Perfect getaway with our all-in-one tourism management system</p>
        
    </section>
    
  <!-- Image Gallery -->
<section class="image-section">
    <h1>Explore Our Gallery</h1>
    <div class="image-gallery">
        <div class="image-item">
            <img src="images/landscape.jpg" alt="Beautiful landscape of Northern Malawi" class="gallery-img">
            <p class="caption">Beautiful Landscape of Northern Malawi</p>
        </div>
        <div class="image-item">
            <img src="images/local market.jpg" alt="Tourists enjoying a local market" class="gallery-img">
            <p class="caption">Tourists Enjoying a Local Market</p>
        </div>
        <div class="image-item">
            <img src="images/sunset.jpg" alt="Sunset over a lake in Malawi" class="gallery-img">
            <p class="caption">Sunset Over a Lake in Malawi</p>
        </div>
        <div class="image-item">
            <img src="images/advanture.jpg" alt="Adventure activities in Malawi" class="gallery-img">
            <p class="caption">Adventure Activities in Malawi</p>
        </div>
        <div class="image-item">
            <img src="images/relaxingbeach.jpg" alt="Relaxing beach view in Northern Malawi" class="gallery-img">
            <p class="caption">Relaxing Beach View in Northern Malawi</p>
        </div>
        <div class="image-item">
            <img src="images/national.jpg" alt="Exploring wildlife in Malawi" class="gallery-img">
            <p class="caption">Exploring Wildlife in Malawi</p>
        </div>
        <div class="image-item">
            <img src="images/taste.jpg" alt="Cultural experience with locals" class="gallery-img">
            <p class="caption">Local Cuisine Tasting</p>
        </div>
        <div class="image-item">
            <img src="images/traditional.jpg" alt="Cultural experience with locals" class="gallery-img">
            <p class="caption">Traditional Dance Performance</p>
        </div>
    </div>
</section>

<!-- Modal for displaying enlarged image and details -->
<div id="image-modal" class="modal">
    <span class="close-btn">&times;</span>
    <div class="modal-content">
        <img id="modal-img" src="" alt="Large View">
        <p id="modal-description"></p>
    </div>
</div>

    <!-- About SmartTour Section -->
    <section class="about" id="about">
        <h2>About Us</h2>
        <div class="tabs">
            <button class="tab-button active" onclick="openTab(event, 'about-tour')">About SmartTour</button>
            <button class="tab-button" onclick="openTab(event, 'mission')">Our Mission</button>
            <button class="tab-button" onclick="openTab(event, 'safety')">Safety Information</button>
        </div>
        
        <div id="about-tour" class="tab-content active">
            <p>SmartTour is a leading tour management company dedicated to providing unforgettable travel experiences in the beautiful Northern Malawi region. With decades of industry expertise, we have curated a diverse portfolio of unique tours that showcase the true essence of Malawian culture, natural wonders, and adventurous activities. Our team of passionate local guides and travel experts work tirelessly to ensure every trip exceeds our guests' expectations.</p>
        </div>
        
        <div id="mission" class="tab-content">
            <h3>Our Mission</h3>
            <p>At the heart of SmartTour lies our unwavering commitment to responsible and sustainable tourism. Our mission is to connect travelers with the breathtaking beauty and rich cultural heritage of Malawi, while prioritizing the well-being of local communities and the preservation of the environment. We believe in empowering our guests to explore the country in a way that creates positive social and economic impact, fostering meaningful connections and lasting memories.</p>
        </div>

        <div id="safety" class="tab-content">
            <h3>Safety Information</h3>
            <p>Ensuring the safety and security of our guests is of the utmost importance at SmartTour. We adhere to the highest industry standards and protocols to mitigate risks and provide a worry-free travel experience. From comprehensive safety briefings and emergency response procedures to the use of well-maintained transportation and equipment, we leave no stone unturned in our pursuit of keeping our travelers safe.</p>
        </div>
    </section>
<!--footer-->
    <footer>
    <div class="footer-container">
        <div class="footer-description">
            <h3>About SmartTour</h3>
            <p>Explore the stunning landscapes and vibrant culture of Northern Malawi with us. Join us for unforgettable experiences!</p>
        </div>
        <div class="footer-links">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Tour Packages</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="ContactUs.php" target="_self">Contact</a></li>
            </ul>
        </div>
        <div class="footer-social">
            <h3>Follow Us</h3>
            <div class="social-icons">
                <a href="#"><i class="ri-facebook-fill"></i></a>
                <a href="#"><i class="ri-twitter-fill"></i></a>
                <a href="#"><i class="ri-instagram-fill"></i></a>
                <a href="#"><i class="ri-linkedin-fill"></i></a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; 2024 Smart Tour. All rights reserved.</p>
    </div>
</footer>
    <script src="main.js"></script>
</body>
</html>