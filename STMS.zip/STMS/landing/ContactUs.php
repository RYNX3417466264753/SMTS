<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="Style.css" />
    <title>SmartTour | Contact Us</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav__header">
                <div class="nav__logo">
                    <a href="#">SMART<span>TOUR</span>.</a>
                </div>
                <div class="nav__menu__btn" id="menu-btn">
                    <span><i class="ri-menu-line"></i></span>
                </div>
            </div>
            <ul class="nav__links" id="nav-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Tour Packages</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="ContactUs.php" target="_self">Contact</a></li>
            </ul>
            <div class="nav__btns">
                <button class="btn sign__up">Sign Up</button>
                <button class="btn sign__in">Sign In</button>
            </div>
        </nav>
    </header>
    
    <!-- Contact Us page -->
    <section class="Contact-info">
        <div class="container">
            <div class="left">
                <h1 class="title">Let's get in touch</h1>
                <h2 class="subtitle">We're open for any suggestion or just to have a chat</h2>
                <div class="image">
                    <img src="images/image.svg" alt="Contact Us Image" />
                </div>
                <div class="info">
                    <span><i class="fa-solid fa-location-dot"></i>P.O BOX 136, Mzuzu, Malawi</span>
                    <span><i class="fa-solid fa-phone"></i>+265 894461169</span>
                    <span><i class="fa-solid fa-envelope"></i>smarttour@gmail.com</span>
                    <span><i class="fa-solid fa-globe"></i>www.smarttour.com</span>
                </div>
            </div>
            <div class="right">
                <h1 class="title">Get In Touch</h1>
                <h2 class="subtitle">Reach out and we'll get in touch within 24 hours.</h2>
                <form action="sendmail.php" class="form" method="POST">
                    <div class="form-field">
                        <i class="fa-solid fa-user icon"></i>
                        <input type="text" name="fullname" placeholder="Your name" id="fullname" required />
                    <small class="error-message"></small> 
                    </div>
                    
                    <div class="form-field">
                        <i class="fa-solid fa-envelope icon"></i>
                        <input type="email" name="email" placeholder="Your email" id="email" required />
                        <small class="error-message"></small>
                    </div>
                    
                    <div class="form-field">
                        <i class="fa-solid fa-phone icon"></i>
                        <input type="text" name="mobilenumber" placeholder="Your phone number" id="mobilenumber" required />
                        <small class="error-message"></small>
                    </div>
                    
                    <div class="form-field">
                        <i class="fa-solid fa-message icon"></i>
                        <textarea placeholder="Leave us your message here" id="message" name="message" required></textarea>
                        <small class="error-message"></small>
                    </div>
                    <button type="submit" name="submitcontact">
                        Send Message <i class="fa-solid fa-paper-plane icon"></i>
                    </button>
                </form>
            </div>
        </div>
    </section>
    
    <footer>
        <div class="footer-container">
            <div class="footer-description">
                <h3>About SmartTour</h3>
                <p>Explore the stunning landscapes and vibrant culture of Northern Malawi with us. Join us for unforgettable experiences!</p>
            </div>
            <div class="footer-links">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Tour Packages</a></li>
                    <li><a href="#about">About Us</a></li>
                    <li><a href="ContactUs.php" target="_self">Contact</a></li>
                </ul>
            </div>
            <div class="footer-social">
                <h3>Follow Us</h3>
                <div class="social-icons">
                    <a href="#"><i class="ri-facebook-fill"></i></a>
                    <a href="#"><i class="ri-twitter-fill"></i></a>
                    <a href="#"><i class="ri-instagram-fill"></i></a>
                    <a href="#"><i class="ri-linkedin-fill"></i></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Smart Tour. All rights reserved.</p>
        </div>
    </footer>
    <script>
        // Select form fields
const nameField = document.getElementById('fullname');
const emailField = document.getElementById('email');
const phoneField = document.getElementById('mobilenumber');
const messageField = document.getElementById('message');
const form = document.querySelector('.form');

// Add error message span elements dynamically
document.querySelectorAll('.form-field').forEach((field) => {
    const errorSpan = document.createElement('span');
    errorSpan.classList.add('error-message');
    field.appendChild(errorSpan);
});

// Validation functions
function validateName() {
    const error = nameField.nextElementSibling;
    const namePattern = /^[A-Za-z\s]+$/; // Only letters and spaces allowed

    if (nameField.value.trim().length < 3) {
        error.textContent = 'Name must be at least 3 characters long.';
        nameField.classList.add('error');
        return false;
    } else if (!namePattern.test(nameField.value.trim())) {
        error.textContent = 'Name should not contain numbers or special characters.';
        nameField.classList.add('error');
        return false;
    } else {
        error.textContent = '';
        nameField.classList.remove('error');
        return true;
    }
}

function validateEmail() {
    const error = emailField.nextElementSibling;
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/; // Email format

    if (!emailPattern.test(emailField.value.trim())) {
        error.textContent = 'Enter a valid email address.';
        emailField.classList.add('error');
        return false;
    } else {
        error.textContent = '';
        emailField.classList.remove('error');
        return true;
    }
}

function validatePhone() {
    const error = phoneField.nextElementSibling;
    const phonePattern = /^[0-9]{9,15}$/; // Numbers only, 9 to 15 digits

    if (!phonePattern.test(phoneField.value.trim())) {
        error.textContent = 'Enter a valid phone number (9-15 digits).';
        phoneField.classList.add('error');
        return false;
    } else {
        error.textContent = '';
        phoneField.classList.remove('error');
        return true;
    }
}

function validateMessage() {
    const error = messageField.nextElementSibling;

    if (messageField.value.trim().length < 10) {
        error.textContent = 'Message must be at least 10 characters long.';
        messageField.classList.add('error');
        return false;
    } else {
        error.textContent = '';
        messageField.classList.remove('error');
        return true;
    }
}


// Real-time validation listeners
nameField.addEventListener('input', validateName);
emailField.addEventListener('input', validateEmail);
phoneField.addEventListener('input', validatePhone);
messageField.addEventListener('input', validateMessage);

    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="main.js">
    </script>
 <script>
        var messageText = "<?= $_SESSION['status'] ?? '';?>";
        if (messageText != '') {
            Swal.fire({
                title: "Thank you!",
                text: messageText,
                icon: "success"
            });
            <?php unset($_SESSION['status']); ?>
        }
    </script>
</body>
</html>
