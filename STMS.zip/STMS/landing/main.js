// Mobile Menu Toggle
document.getElementById('menu-btn').addEventListener('click', function() {
    const navLinks = document.getElementById('nav-links');
    navLinks.classList.toggle('open'); // Toggle the 'open' class for the menu
});

// Close the mobile menu when a link is clicked
const navItems = document.querySelectorAll('.nav__links a');
navItems.forEach(item => {
    item.addEventListener('click', () => {
        const navLinks = document.getElementById('nav-links');
        navLinks.classList.remove('open'); // Close menu after a link is clicked
    });
});

// Search Functionality
document.querySelector('.search-bar button').addEventListener('click', function() {
    const searchTerm = document.querySelector('.search-bar input').value;
    if (searchTerm) {
        window.location.href = `search.html?q=${encodeURIComponent(searchTerm)}`;
    }
});

// Tabbed Interface for About Us Section
function openTab(evt, tabName) {
    // Get all tab content elements and hide them
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(content => {
        content.classList.remove('active');
    });

    // Get all tab buttons and remove the active class
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.classList.remove('active');
    });

    // Show the current tab and add an active class to the button that opened the tab
    document.getElementById(tabName).classList.add('active');
    evt.currentTarget.classList.add('active');
}

// Get modal element
var modal = document.getElementById('imageModal');
var modalImg = document.getElementById("modalImage");
var modalDescription = document.getElementById("modalDescription");

// Get all images
var images = document.querySelectorAll(".gallery-img");

// Open Modal when image is clicked
images.forEach(function(image) {
    image.addEventListener('click', function() {
        modal.style.display = "flex"; // Show modal
        modalImg.src = this.src; // Set the modal image source to clicked image
        modalDescription.textContent = this.nextElementSibling.textContent; // Set description
    });
});

// Close Modal
function closeModal() {
    modal.style.display = "none";
}
